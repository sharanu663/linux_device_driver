#include <zephyr/device.h>

#include <zephyr/logging/log.h>

#include "temperature_sensor.h"

#include "say_hello.h"

#include <zephyr/kernel.h>


LOG_MODULE_REGISTER(main_app,LOG_LEVEL_DBG);


int main(void)
{
    while(1)
    {
        int ret=0;
        ret = test_function(10,20);
        LOG_INF("sum of two number = %d\n",ret);

        ret = mul(10,20);
        LOG_INF("mul of two number = %d\n",ret);
        k_msleep(2000);
    }

    return 0;

}
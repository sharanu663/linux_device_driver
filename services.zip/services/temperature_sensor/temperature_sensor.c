
#include <zephyr/device.h>

#include <zephyr/logging/log.h>

//#ifdef MYFUNCTION
#include "temperature_sensor.h"
//#endif

LOG_MODULE_REGISTER(tess,LOG_LEVEL_DBG);


int test_function(int n1,int n2)
{

    int sum;
    sum = n1+n2;
    return sum;
}
#ifndef TEMPERATURE_SENSOR_H
#define TEMPERATURE_SENSOR_H

#include <stdint.h>
#include <stddef.h>

int test_function(int n1,int n2);

#endif 
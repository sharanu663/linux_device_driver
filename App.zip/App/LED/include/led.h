
#ifndef LED_H
#define LED_H


#include <zephyr/kernel.h>
#include <zephyr/drivers/gpio.h>

extern struct k_mutex my_mutex;



int led_initialize(void);
void org_green_led(void *,void *, void *);

void blue_red_led(void *,void *, void *);




#endif
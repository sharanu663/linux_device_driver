#ifndef ADC_TEMP_H
#define ADC_TEMP_H


int temp_init(void);
void temprature(void *,void *,void *);


#endif
/*
 * Copyright (c) 2016 Intel Corporation
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include <stdio.h>
#include <zephyr/kernel.h>
#include <zephyr/drivers/gpio.h>


#include "led.h"
#include "adc_temp.h"

/* 1000 msec = 1 sec */
#define SLEEP_TIME_MS   1000



#define MY_STACK_SIZE 512
#define PRIORITY_TH0 4
#define PRIORITY_TH1 5
#define PRIORITY_TH2 6

k_tid_t thread0_id,thread1_id,thread2_id;
k_thread_stack_t *stack_th0,*stack_th1, *stack_th2;
struct k_thread thread0_data,thread1_data,thread2_data;

struct k_mutex my_mutex={0};



int main(void)
{
	//int ret;

	led_initialize();
  temp_init();
  k_mutex_init(&my_mutex);
	printf("main function entered\n");

	stack_th0 = k_thread_stack_alloc(CONFIG_DYNAMIC_THREAD_STACK_SIZE,0);
	if(stack_th0 == NULL)
	printf("memory allocation failed of thread0 \n");

  stack_th1 = k_thread_stack_alloc(CONFIG_DYNAMIC_THREAD_STACK_SIZE,0);
	if(stack_th1 == NULL)
	printf("memory allocation failed of thread1 \n");

  stack_th2 = k_thread_stack_alloc(CONFIG_DYNAMIC_THREAD_STACK_SIZE,0);
	if(stack_th2 == NULL)
	printf("memory allocation failed of thread2 \n");


  thread0_id = k_thread_create(&thread0_data, stack_th0,CONFIG_DYNAMIC_THREAD_STACK_SIZE,
                                  org_green_led, NULL,NULL,NULL,PRIORITY_TH0,0,K_NO_WAIT);

  thread1_id = k_thread_create(&thread1_data, stack_th1,CONFIG_DYNAMIC_THREAD_STACK_SIZE,
                                  blue_red_led, NULL,NULL,NULL,PRIORITY_TH1,0,K_NO_WAIT);
    
  thread2_id = k_thread_create(&thread2_data, stack_th2,CONFIG_DYNAMIC_THREAD_STACK_SIZE,
                                    temprature, NULL,NULL,NULL,PRIORITY_TH2,0,K_NO_WAIT);



  k_thread_join(thread0_id,K_FOREVER);
  k_thread_join(thread1_id,K_FOREVER);
  k_thread_join(thread2_id,K_FOREVER);

    // k_thread_stack_free(stack_th0);
    // k_thread_stack_free(stack_th1);
	return 0;
}




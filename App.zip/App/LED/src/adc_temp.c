
#include "adc_temp.h"
#include <zephyr/kernel.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/sensor.h>


#define DIE_TEMP_ALIAS(i) DT_ALIAS(_CONCAT(die_temp, i))
#define DIE_TEMPERATURE_SENSOR(i, _)                                                               \
	IF_ENABLED(DT_NODE_EXISTS(DIE_TEMP_ALIAS(i)), (DEVICE_DT_GET(DIE_TEMP_ALIAS(i)),))

/* support up to 16 cpu die temperature sensors */
static const struct device *const sensors = {LISTIFY(1, DIE_TEMPERATURE_SENSOR, ())};

// LISTIFY : it will expand like below example shown
//  *     #define FOO(i, _) MY_PWM ## i
//  *     { LISTIFY(PWM_COUNT, FOO, (,)) }
//  *
//  * The above two lines expand to:
//  *
//  *    { MY_PWM0 , MY_PWM1 }


//or  this for single die temprature sensor and above one multipal die temprature sesnor 
// #define DIE_temp  DT_ALIAS(temp_die)
// static const struct device *const sensors = DEVICE_DT_GET(DIE_temp);



int temp_init(void){

	if (!device_is_ready(sensors)) {
		printk("sensor: device %s not ready.\n", sensors->name);
		return 0;
	}
	return 0;
}


void temprature(void *,void *,void *)
{

	struct sensor_value val;
	int rc;

	while(1) 
	{
		  printf("thread2 function\n");
		/* fetch sensor samples */
		rc = sensor_sample_fetch(sensors);
		if (rc) {
			printk("Failed to fetch sample (%d)\n", rc);
			//return rc;
		}

		rc = sensor_channel_get(sensors, SENSOR_CHAN_DIE_TEMP, &val);
		if (rc) {
			printk("Failed to get data (%d)\n", rc);
			//return rc;
		}

		printk("CPU Die temperature[%s]: %.1f °C\n", sensors->name, sensor_value_to_double(&val));   
		k_msleep(550);
	}
	//return 0;
}
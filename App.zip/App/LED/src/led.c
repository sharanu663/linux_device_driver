
#include <stdio.h>


#include "led.h"
#include "adc_temp.h"

#define LED0 DT_ALIAS(or_led)
#define LED1 DT_ALIAS(ge_led)
#define LED2 DT_ALIAS(re_led)
#define LED3 DT_ALIAS(bl_led)

#define SLEEP_TIME_200MS   200
#define SLEEP_TIME_150MS   100


enum staus_led{
    OFF_led,
    ON_led,
};

const struct gpio_dt_spec org_led0 = GPIO_DT_SPEC_GET(LED0, gpios);
const struct gpio_dt_spec green_led1 = GPIO_DT_SPEC_GET(LED1, gpios);
const struct gpio_dt_spec red_led2 = GPIO_DT_SPEC_GET(LED2, gpios);
const struct gpio_dt_spec blue_led3 = GPIO_DT_SPEC_GET(LED3, gpios);


int led_initialize(void)
{

    int ret;

    if (!gpio_is_ready_dt(&org_led0)) {
		return 0;
	}

	ret = gpio_pin_configure_dt(&org_led0, GPIO_OUTPUT_ACTIVE);
	if (ret < 0) {
		return 0;
	}

    if (!gpio_is_ready_dt(&green_led1)) {
		return 0;
	}

	ret = gpio_pin_configure_dt(&green_led1, GPIO_OUTPUT_ACTIVE);
	if (ret < 0) {
		return 0;
	}

    if (!gpio_is_ready_dt(&red_led2)) {
		return 0;
	}

	ret = gpio_pin_configure_dt(&red_led2, GPIO_OUTPUT_ACTIVE);
	if (ret < 0) {
		return 0;
	}

    if (!gpio_is_ready_dt(&blue_led3)) {
		return 0;
	}

	ret = gpio_pin_configure_dt(&blue_led3, GPIO_OUTPUT_ACTIVE);
	if (ret < 0) {
		return 0;
	}

    return 0;
}
void org_green_led(void *,void *, void *)
{
     //printf("thread0 before function\n");

    while(1)
    {
        k_mutex_lock(&my_mutex, K_FOREVER);

        printf("thread0 on function\n");
    

        gpio_pin_set_dt(&org_led0 , ON_led);
        //k_msleep(SLEEP_TIME_250MS);
        gpio_pin_set_dt(&green_led1, ON_led);
        
        k_msleep(500);
        //k_yield();
        //k_busy_wait(1000000);

        printf("thread0 off function\n");

        gpio_pin_set_dt(&org_led0 , OFF_led);
        
        //k_msleep(SLEEP_TIME_250MS);
        
        gpio_pin_set_dt(&green_led1, OFF_led);

        k_mutex_unlock(&my_mutex);

        k_msleep(500);
        //k_yield();
        //k_busy_wait(1000000);
        
    }



}

void blue_red_led(void *,void *, void *)
{

    //printf("thread1 before function\n");
    while(1)
    {

        k_mutex_lock(&my_mutex, K_FOREVER);

        printf("thread1 on function\n");

        gpio_pin_set_dt(&red_led2, ON_led);
        
        //k_msleep(SLEEP_TIME_250MS);
        
        gpio_pin_set_dt(&blue_led3, ON_led);

        k_msleep(500);
        //k_yield();
        //k_busy_wait(1000000);

        printf("thread1 off function\n");

        gpio_pin_set_dt(&red_led2 , OFF_led);
        
        //k_msleep(SLEEP_TIME_250MS);
        
        gpio_pin_set_dt(&blue_led3, OFF_led);
        
        k_mutex_unlock(&my_mutex);
        
        k_msleep(500);
        //k_yield(); 
        //k_busy_wait(1000000); using for debug not for production code
    }
    
}